What's new in version 6.37 Build 14
(Released: May 01, 2020)
- Fixed "endless reboot" problem when changing IDM Network integration on Windows 7
- Fixed bugs

System Requirements:
Operating System: Windows XP, NT, 2000, Vista, 7, 8, 8.1 & 10
Memory (RAM): 512 MB of RAM required
Hard Disk Space: 25 MB of free space required for full installation
Processor: Intel Pentium 4 Dual Core GHz or higher

How to Install:
1. Install "idman637build14.exe"
2. Extract "Patcher.zip" (Password is: 123)
3. Install "Patcher.exe"
4. Done!!! Enjoy!!!

--------------------------------
Cracked by: www.crackingcity.com